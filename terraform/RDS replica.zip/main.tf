#############################
# DB Subnet Group (Private)
#############################
resource "aws_db_subnet_group" "this" {
  name       = "${var.project}-rds-subnet-group"
  subnet_ids = var.private_subnet_ids

  tags = {
    Name = "${var.project}-rds-subnet-group"
  }
}

#############################
# RDS Security Group
#############################
resource "aws_security_group" "rds" {
  name   = "${var.project}-rds-sg"
  vpc_id = var.vpc_id

  # 지금 단계에선 보통 비워둠(allowed_mysql_cidrs = [])
  dynamic "ingress" {
    for_each = var.allowed_mysql_cidrs
    content {
      description = "MySQL from allowed CIDRs"
      from_port   = 3306
      to_port     = 3306
      protocol    = "tcp"
      cidr_blocks = [ingress.value]
    }
  }

  egress {
    description = "All outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project}-rds-sg"
  }
}

#############################
# Parameter Group (관측용 최소)
#############################
resource "aws_db_parameter_group" "mysql" {
  name   = "${var.project}-mysql-pg"
  family = var.mysql_family

  parameter {
    name  = "slow_query_log"
    value = "1"
  }

  parameter {
    name  = "long_query_time"
    value = "2"
  }

  tags = {
    Name = "${var.project}-mysql-pg"
  }
}

#############################
# RDS Instance
#############################
resource "aws_db_instance" "this" {
  identifier = var.db_identifier

  engine         = "mysql"
  engine_version = var.mysql_engine_version

  instance_class    = var.db_instance_class
  allocated_storage = var.db_allocated_storage

  db_name  = var.db_name
  username = var.db_username
  password = var.db_password

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.rds.id]
  parameter_group_name   = aws_db_parameter_group.mysql.name

  publicly_accessible = false
  multi_az            = var.multi_az

  backup_retention_period = 7
  deletion_protection     = var.deletion_protection
  skip_final_snapshot     = var.skip_final_snapshot

  tags = {
    Name = var.db_identifier
  }
}
