project = "migration"
region  = "ap-northeast-2"

vpc_id = "vpc-08c20a53acfc8d82b"

private_subnet_ids = [
  "subnet-0e3b6111d0ccd76a1", # private-a
  "subnet-0123b631b414e11ee", # private-b
]

db_identifier = "migration-mysql"
db_name       = "appdb"

db_username = "admin"
db_password = "ChangeMe-StrongPassword123!"

multi_az = true

# 지금은 VPN/앱 연결 전이라 비워도 됨 (인바운드 0개가 되어 "아무도 못 들어오는 DB"가 됨)
allowed_mysql_cidrs = []
