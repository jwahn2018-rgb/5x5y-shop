variable "project" {
  type = string
}

variable "region" {
  type = string
}

variable "vpc_id" {
  type = string
}

variable "private_subnet_ids" {
  type        = list(string)
  description = "RDS 배치용 private subnet ids (2개 이상)"
}

variable "allowed_mysql_cidrs" {
  type        = list(string)
  description = "RDS 3306 인바운드 허용 CIDR (현재 모르면 빈 리스트)"
  default     = []
}

variable "db_identifier" {
  type    = string
  default = "migration-mysql"
}

variable "db_name" {
  type    = string
  default = "appdb"
}

variable "db_username" {
  type = string
}

variable "db_password" {
  type = string
}

variable "db_instance_class" {
  type    = string
  default = "db.t3.micro"
}

variable "db_allocated_storage" {
  type    = number
  default = 20
}

variable "multi_az" {
  type    = bool
  default = true
}

variable "mysql_engine_version" {
  type    = string
  default = "8.0.43"
}

variable "mysql_family" {
  type    = string
  default = "mysql8.0"
}

variable "deletion_protection" {
  type    = bool
  default = false
}

variable "skip_final_snapshot" {
  type    = bool
  default = true
}
