terraform {
  required_version = ">= 1.4.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

# 서울(리전 리소스: ALB, REGIONAL WAF 등)
provider "aws" {
  region = var.region
}

# us-east-1(CloudFront용 WAF는 여기서 생성/관리)
provider "aws" {
  alias  = "use1"
  region = "us-east-1"
}
