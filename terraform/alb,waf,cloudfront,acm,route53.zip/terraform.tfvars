route53_zone_id = "Z0071336AIYGWKCDKBOY"

alb_acm_certificate_arn = "arn:aws:acm:ap-northeast-2:004932907894:certificate/1f667fa4-126d-47dc-aafa-5b933521d3c5"
cf_acm_certificate_arn  = "arn:aws:acm:us-east-1:004932907894:certificate/d1ba6a8d-f729-4328-99ec-c21db3c7627e"

# tg_ip_targets = ["10.3.0.2"]  # 필요하면 주석 해제
