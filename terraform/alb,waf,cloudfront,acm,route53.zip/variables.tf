variable "region" {
  type    = string
  default = "ap-northeast-2"
}

variable "project" {
  type    = string
  default = "migration"
}

# 기존 팀 VPC / 서브넷(고정값)
variable "vpc_id" {
  type    = string
  default = "vpc-08c20a53acfc8d82b"
}

variable "public_subnet_ids" {
  type    = list(string)
  default = [
    "subnet-0fc586c23de4fec93",
    "subnet-024c73f8f41961bb4",
  ]
}

# 도메인/존(너희는 aws.minn.my Hosted Zone을 사용 중)
variable "domain_name" {
  type    = string
  default = "aws.minn.my"
}

variable "route53_zone_id" {
  type = string
}

# ALB HTTPS용 서울 ACM ARN (필수)
variable "alb_acm_certificate_arn" {
  type = string
}

# CloudFront HTTPS용 us-east-1 ACM ARN (Issued된 것) (필수)
variable "cf_acm_certificate_arn" {
  type = string
}

# Target Group 세팅
variable "target_port" {
  type    = number
  default = 80
}

# 하이브리드(온프렘 WAF/RP 등) 연결을 고려해 ip 타입 기본
variable "tg_ip_targets" {
  type    = list(string)
  default = []
}
